const passport = require('passport');
const router = require('express').Router();
const UndanganController = require('../controllers/Undangan.js');


// create PenarikanVet
router.post('/Undangan/create', UndanganController.create);

// get all Undangan
router.get('/Undangan/getall', UndanganController.getAll);

// get Undangan by id pemilik
//router.get('/Undangan/getbyidpemilik/:id',UndanganController.getById);

// get by id Undangan
router.get('/Undangan/:id', UndanganController.getById);

// update Undangan
router.put(
  '/Undangan/update/:id',[passport.authenticate('admin', { session: false })],
   UndanganController.update
);

// delete Undangan
router.delete(
  '/Undangan/delete/:id',[passport.authenticate('admin', { session: false })],
    UndanganController.delete
);

module.exports = router;
