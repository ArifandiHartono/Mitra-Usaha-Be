const passport = require('passport');
const router = require('express').Router();
const UserController = require('../controllers/User.js');

// create PenarikanVet
router.post('/User/create', UserController.create);

// get all User
router.get('/User/getall',[passport.authenticate('admin', { session: false })],UserController.getAll);

// get User by id pemilik
//router.get('/User/getbyidpemilik/:id',UserController.getById);

// get by id User
router.get('/User/:id', UserController.getById);
router.get('/User/generateidforqr/:code', UserController.getIDbyCode);

// update User
router.put(
  '/User/update/:id',[passport.authenticate('admin', { session: false })],
   UserController.update
);

router.put(
  '/User/updatestatus/:id',passport.authenticate('admin', { session: false }),
   UserController.changestatus
);

router.put(
  '/User/updatestatussouvenir/:id',passport.authenticate('admin', { session: false }),
   UserController.changestatussouvenir
);


// delete User
router.delete(
  '/User/delete/:id',
    UserController.delete
);

module.exports = router;
