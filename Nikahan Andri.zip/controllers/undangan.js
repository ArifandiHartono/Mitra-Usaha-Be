const tokenGenerator = require('../services/token-generator');
const { Undangan } = require('../models');
const config = require('../config');

class UndanganController {
    async create(req, res) {
        try {
          const result = await Undangan.create(req.body);
          res.status(200).json({
            status: 'Success',
            data: result,
          });
        } catch (error) {
          res.status(500).json({
            status: 'Error',
            message: 'Request failed',
          });
        }
      }
    
      async getAll(req, res) {
        try {
          const result = await Undangan.findAll();
          
          res.status(200).json({
            status: 'Success',
            data: result,
          });
        } catch (error) {
          res.status(500).json({
            status: 'Error',
            message: 'Request failed',
            erross: error
          });
        }
      }
    
      async getById(req, res) {
        try {
          const result = await Undangan.findAll({ where: { id: req.params.id } });
          res.status(200).json({
            status: 'Success',
            data: result,
          });
        } catch (error) {
          res.status(500).json({
            status: 'Error',
            message: 'Request failed',
          });
        }
      }
    
      async update(req, res) {
        try {
          await Undangan.update(req.body, { where: { id: req.params.id } });
          const result = await Undangan.findOne({ where: { id: req.params.id } });
          res.status(200).json({
            status: 'Success',
            data: result,
          });
        } catch (error) {
          res.status(500).json({
            status: 'Error',
            message: 'Request failed',
          });
        }
      }
    
      async delete(req, res) {
        try {
          await Undangan.destroy({ where: { id: req.params.id } });
          res.status(200).json({
            status: 'Success',
            message: 'Undangan deleted',
          });
        } catch (error) {
          res.status(500).json({
            status: 'Error',
            message: 'Request failed',
          });
        }
      }
    }
    
    module.exports = new UndanganController();