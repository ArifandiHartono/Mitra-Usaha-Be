const tokenGenerator = require('../services/token-generator');
const { User } = require('../models');
const config = require('../config');

class UserController {
    async create(req, res) {
        try {
          let user = await User.count({where: {name : req.body.name}})
          if(user >= 0)
          {
            res.status(400).json({
              status: 'Failed',
              message: "User Already Registered" ,
            });
          }else{
          var val = Math.floor(100 + Math.random() * 900);
          console.log(val)
          req.body.code = null;
          const result = await User.create(req.body);
          result.code = result.id.toString() + val;
          result.status = "Belum Hadir"
          result.save()
          res.status(200).json({
            status: 'Success',
            data: result,
          });
        }
        } catch (error) {
          res.status(500).json({
            status: 'Error',
            message: 'Request failed',
          });
        }
      }
    
      async getAll(req, res) {
        console.log("sini")
        try {
          const result = await User.findAll();
          
          res.status(200).json({
            status: 'Success',
            data: result,
          });
        } catch (error) {
          res.status(500).json({
            status: 'Error',
            message: 'Request failed',
            erross: error
          });
        }
      }
    
      async getById(req, res) {
        try {
          const result = await User.findAll({ where: { id: req.params.id } });
          res.status(200).json({
            status: 'Success',
            data: result,
          });
        } catch (error) {
          res.status(500).json({
            status: 'Error',
            message: 'Request failed',
          });
        }
      }

      async getIDbyCode(req, res) {
        try {
          const result = await User.findAll({ where: { phone: req.params.phone } });
          res.status(200).json({
            status: 'Success',
            data: result,
          });
        } catch (error) {
          res.status(500).json({
            status: 'Error',
            message: 'Request failed',
          });
        }
      }
    
      async update(req, res) {
        try {
          let user = await User.findOne({where: {id  : req.params.id}})
          if(user >= 0 && user.id != req.params.id)
          {
            res.status(400).json({
              status: 'Failed',
              message: "User Already Registered" ,
            });
          }else{
          await User.update(req.body, { where: { id: req.params.id } });
          const result = await User.findOne({ where: { id: req.params.id } });
          res.status(200).json({
            status: 'Success',
            data: result,
          });
        }
        } catch (error) {
          res.status(500).json({
            status: 'Error',
            message: 'Request failed',
          });
        }
      }
    
      async changestatus(req, res) {
        try {
          await User.update({statushadir : req.body.status }, { where: { id: req.params.id } });
          const result = await User.findOne({ where: { id: req.params.id } });
          res.status(200).json({
            status: 'Success',
            data: result,
          });
        } catch (error) {
          res.status(500).json({
            status: 'Error',
            message: 'Request failed',
          });
        }
      }

      
      async changestatussouvenir(req, res) {
        try {
          await User.update({statussouvenir : req.body.status }, { where: { id: req.params.id } });
          const result = await User.findOne({ where: { id: req.params.id } });
          res.status(200).json({
            status: 'Success',
            data: result,
          });
        } catch (error) {
          res.status(500).json({
            status: 'Error',
            message: 'Request failed',
          });
        }
      }

      async delete(req, res) {
        try {
          await User.destroy({ where: { id: req.params.id } });
          res.status(200).json({
            status: 'Success',
            message: 'User deleted',
          });
        } catch (error) {
          res.status(500).json({
            status: 'Error',
            message: 'Request failed',
          });
        }
      }
    }
    
    module.exports = new UserController();